#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
dkp-pacman -Syu --noconfirm
dkp-pacman -S --needed --noconfirm switch-curl switch-zlib switch-libopus switch-ffmpeg switch-libwebp switch-glfw switch-mesa switch-libdrm_nouveau
bash scripts/bootstrap-cloud-lite.sh
bash scripts/test-startup.sh
bash scripts/build-switch.sh
mkdir -p release
cp build-switch/vkpcnx.nro release/cloud-lite-nx.nro
gzip -c build-switch/vkpcnx.elf > release/cloud-lite-nx-symbols.elf.gz
