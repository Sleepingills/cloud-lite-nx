#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Archives do not retain gitlinks. Fetch the exact upstream UI revision.
if [[ ! -f library/borealis/library/cmake/commonOption.cmake ]]; then
  git clone https://github.com/xfangfang/borealis.git library/borealis
  git -C library/borealis checkout 3ecf2de10226392ecb071c470bea9758a24cd6b1
fi
# Required by desktop builds; the Switch build uses devkitPro GLFW.
if [[ -d library/borealis/.git || -f library/borealis/.git ]]; then
  git -C library/borealis submodule update --init --recursive
fi
