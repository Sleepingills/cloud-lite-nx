#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
JSON_INCLUDE=${JSON_INCLUDE:-library/borealis/library/include/borealis/extern}
mkdir -p build-startup-tests
"${CXX:-g++}" -std=c++17 -Wall -Wextra -Werror -Ivkpcnx/include -I"$JSON_INCLUDE" \
  tests/auth_reply_test.cpp -o build-startup-tests/auth_reply_test
./build-startup-tests/auth_reply_test
python3 - <<'PY'
from pathlib import Path
import re
for name in ('login', 'main'):
    text = Path(f'resources/xml/activity/{name}.xml').read_text()
    ids = re.findall(r'\bid="([^"]+)"', text)
    assert len(ids) == len(set(ids)), f'Duplicate view ID in {name}'
    cpp = Path(f'vkpcnx/src/activity/{name}_activity.cpp').read_text()
    for view in re.findall(r'getView\("([^"]+)"\)', cpp):
        assert view in ids, f'Missing view {view}'
print('Startup view identifiers verified')
PY
