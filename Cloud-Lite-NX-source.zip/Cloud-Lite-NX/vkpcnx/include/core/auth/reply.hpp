#pragma once
// Cloud Lite NX: pure response validation, also exercised by host-side tests.
#include <nlohmann/json.hpp>
#include <string>

namespace vkpcnx::auth {
using Json = nlohmann::json;
enum class Stage { Init, Poll, Exchange };
enum class State { Ready, Pending, Failed };
struct Reply {
  State state = State::Failed;
  Json data;
  std::string message;
};
inline bool textField(const Json &j, const char *key) {
  return j.is_object() && j.contains(key) && j.at(key).is_string() &&
         !j.at(key).get_ref<const std::string &>().empty();
}
inline Reply parse(Stage stage, long status, int transport, const std::string &body) {
  if (transport != 0 || status == 0) {
    std::string message;
    switch (transport) {
    case 6: message = "Не удалось найти сервер. Проверьте интернет и DNS."; break;
    case 7: message = "Не удалось подключиться к серверу."; break;
    case 28: message = "Сервер не ответил вовремя. Можно повторить подключение."; break;
    case 35: case 60:
      message = "Ошибка защищённого соединения. Проверьте дату и время консоли."; break;
    default: message = "Ошибка сети. Проверьте подключение к интернету."; break;
    }
    return {State::Failed, {}, message + " Код сети: " + std::to_string(transport)};
  }
  if (status < 200 || status >= 300) {
    std::string message = status == 429 ? "Слишком много запросов. Подождите минуту." :
      status >= 500 ? "Сервис временно недоступен. Попробуйте позже." :
      status == 401 || status == 403 ? "Сервер отклонил запрос авторизации." :
      "Сервер вернул ошибку.";
    return {State::Failed, {}, message + " HTTP " + std::to_string(status)};
  }
  auto j = Json::parse(body, nullptr, false);
  if (!j.is_object())
    return {State::Failed, {}, "Неожиданный ответ сервера: ожидался JSON-объект."};
  if (stage == Stage::Init && textField(j, "code") && textField(j, "token"))
    return {State::Ready, j, {}};
  if (stage == Stage::Exchange && textField(j, "access_token"))
    return {State::Ready, j, {}};
  if (stage == Stage::Poll) {
    if (textField(j, "oauth2_code")) return {State::Ready, j, {}};
    if ((!j.contains("oauth2_code") || j["oauth2_code"].is_null() ||
         j["oauth2_code"] == "") && !j.contains("error"))
      return {State::Pending, {}, {}};
  }
  return {State::Failed, {}, "Ответ сервера не соответствует ожидаемому формату входа."};
}
} // namespace vkpcnx::auth
