#pragma once
// Lightweight declarations for startup screens; implementations live in the
// existing lifecycle code and the onboarding adapter respectively.
namespace vkpcnx::utils {
void relaunch();
void showOnboarding();
}
