// Modified for Cloud Lite NX: startup reliability and custom identification.
#pragma once
#include <borealis.hpp>
#include <nlohmann/json.hpp>
#include <optional>

class AccountInfo {
public:
  static AccountInfo &instance();
  const std::optional<nlohmann::json> &get() const;
  void fetch();
  void clear();
  // Publish on the UI thread after a background fetch.
  void publish(const nlohmann::json &account);

  brls::Event<const nlohmann::json &> &updated() { return onUpdated; }

private:
  std::optional<nlohmann::json> cached;
  bool inFlight = false;
  brls::Event<const nlohmann::json &> onUpdated;
};