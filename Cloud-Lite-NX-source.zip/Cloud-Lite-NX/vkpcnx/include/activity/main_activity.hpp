// Modified for Cloud Lite NX: startup reliability and custom identification.
#pragma once
#include "core/account_info.hpp"
#include "view/games_data_source.hpp"
#include "view/title_bar.hpp"
#include <borealis.hpp>
#include <atomic>
#include <memory>

class MainActivity : public vkpcnx::CustomTitlebarActivity {
public:
  MainActivity() : CustomTitlebarActivity("main/root") {}
  ~MainActivity() override { alive->store(false); }
  CONTENT_FROM_XML_RES("activity/main.xml");
  BRLS_BIND(brls::AppletFrame, appletFrame, "main/root");
  void onContentReady() override;
private:
  BRLS_BIND(brls::Box, loader, "main/loader");
  BRLS_BIND(brls::RecyclerFrame, content, "main/content");
  std::shared_ptr<std::atomic_bool> alive = std::make_shared<std::atomic_bool>(true);
  int page = 0;
  bool loading = false;
  bool hasMore = true;
  bool failed = false;
  bool catalogueCreated = false;
  vkpcnx::GamesDataSource::MoreGamesCallback retryPage;
  void overrideBackAction();
  void loadAccount();
  void showFailure(const std::string &message);
  void renderGamesList();
  void fetchMoreGames(vkpcnx::GamesDataSource::MoreGamesCallback cb);
};
