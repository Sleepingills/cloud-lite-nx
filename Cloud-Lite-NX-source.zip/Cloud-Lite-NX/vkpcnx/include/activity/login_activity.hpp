// Modified for Cloud Lite NX: startup reliability and custom identification.
#pragma once
#include "activity/main_activity.hpp"
#include "core/settings.hpp"
#include "core/utils/thread.hpp"
#include "view/debug_report.hpp"
#include "view/title_bar.hpp"
#include <atomic>
#include <memory>

class LoginActivity : public vkpcnx::CustomTitlebarActivity {
public:
  LoginActivity() : CustomTitlebarActivity("login/root") {}
  ~LoginActivity() override { if (attempt) attempt->store(false); }
  CONTENT_FROM_XML_RES("activity/login.xml");
  BRLS_BIND(brls::AppletFrame, appletFrame, "login/root");
  void onContentReady() override;
private:
  // Each attempt owns a cancellation flag. Queued UI callbacks check it before
  // touching this activity, including after destruction or a successful login.
  std::shared_ptr<std::atomic_bool> attempt;
  bool busy = false; // UI thread only
  void startLogin();
  void showFailure(const std::string &message);
};
