#include "core/utils/navigation.hpp"
#include "activity/onboarding_activity.hpp"
namespace vkpcnx::utils {
void showOnboarding() {
  brls::Application::pushActivity(new OnboardingActivity());
}
}
