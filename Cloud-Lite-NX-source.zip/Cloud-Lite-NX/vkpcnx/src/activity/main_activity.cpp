// Modified for Cloud Lite NX: startup reliability and custom identification.
#include "activity/main_activity.hpp"
#include "borealis/core/view.hpp"
#include "core/account_info.hpp"
#include "core/utils/thread.hpp"
#include "core/vkpcapi.hpp"
#include "view/game_card_row.hpp"
#include "view/games_data_source.hpp"
#include <string>
#include "core/settings.hpp"
#include "core/utils/navigation.hpp"
#include "view/debug_report.hpp"

using namespace brls::literals;

// After login this activity sits on top of LoginActivity (borealis never
// pops the root), so the frame's default B would pop back to the login
// screen. Behave like a root activity instead: offer to exit the app.
void MainActivity::overrideBackAction() {
  appletFrame->registerAction(
    "hints/exit"_i18n,
    brls::BUTTON_B,
    [](brls::View *) {
      auto *dialog = new brls::Dialog("hints/exit_hint"_i18n);
      dialog->addButton("hints/cancel"_i18n, [] {});
      dialog->addButton("hints/ok"_i18n, [] { brls::Application::quit(); });
      dialog->setCancelable(true);
      dialog->open();
      return true;
    },
    true,
    false,
    brls::SOUND_BACK
  );
}

void MainActivity::renderGamesList() {
  vkpcnx::GamesDataSource::OnNeedMore onNeedMore =
    [this](vkpcnx::GamesDataSource::MoreGamesCallback cb) { this->fetchMoreGames(cb); };

  this->content->registerCell("GameCardRow", []() { return vkpcnx::GameCardRow::create(); });
  this->content->setDataSource(new vkpcnx::GamesDataSource(onNeedMore));
}

void MainActivity::onContentReady() {
  overrideBackAction();
  registerExitAction();
  appletFrame->registerAction("Повторить", brls::BUTTON_X, [this](brls::View *) {
    if (!loading && failed) {
      if (retryPage) fetchMoreGames(retryPage);
      else loadAccount();
    }
    return true;
  });
  appletFrame->registerAction("Отчёт", brls::BUTTON_Y, [](brls::View *) {
    vkpcnx::openDebugReportDialog(); return true;
  });
  appletFrame->registerAction("Войти заново", brls::BUTTON_BACK, [this](brls::View *) {
    if (loading || !failed) return true;
    auto *dialog = new brls::Dialog("Выйти из аккаунта и открыть вход заново?");
    dialog->addButton("Отмена", [] {});
    dialog->addButton("Войти", [] {
      Settings::instance().remove("account");
      AccountInfo::instance().clear();
      vkpcnx::utils::relaunch();
    });
    dialog->open();
    return true;
  });
  loadAccount();
}

void MainActivity::showFailure(const std::string &message) {
  loading = false;
  failed = true;
  loader->setVisibility(brls::Visibility::GONE);
  content->setVisibility(brls::Visibility::GONE);
  static_cast<brls::Label *>(getView("main/errorText"))->setText(message);
  getView("main/error")->setVisibility(brls::Visibility::VISIBLE);
}

void MainActivity::loadAccount() {
  if (loading) return;
  loading = true;
  failed = false;
  getView("main/error")->setVisibility(brls::Visibility::GONE);
  loader->setVisibility(brls::Visibility::VISIBLE);
  const auto life = alive;
  try {
    vkpcnx::utils::runDetached([this, life] {
      nlohmann::json account;
      try { account = VKPCAPI::usersMe(); } catch (const std::exception &) {}
      brls::sync([this, life, account = std::move(account)] {
        if (!life->load()) return;
        loading = false;
        if (!account.is_object() || !account.contains("name") || !account["name"].is_string() ||
            !account.contains("session") || !account["session"].is_object() ||
            !account["session"].contains("user_id") || !account["session"]["user_id"].is_number_integer()) {
          showFailure("Не удалось загрузить профиль. Проверьте интернет. Если повтор не помогает, войдите заново.");
          return;
        }
        AccountInfo::instance().publish(account);
        if (!catalogueCreated) { catalogueCreated = true; renderGamesList(); }
      });
    });
  } catch (const std::exception &) {
    showFailure("Не удалось запустить загрузку профиля. Попробуйте снова.");
  }
}

void MainActivity::fetchMoreGames(vkpcnx::GamesDataSource::MoreGamesCallback cb) {
  if (loading || !hasMore) return;
  loading = true;
  failed = false;
  retryPage = cb;
  getView("main/error")->setVisibility(brls::Visibility::GONE);
  if (page == 0) loader->setVisibility(brls::Visibility::VISIBLE);
  const int requestedPage = page + 1;
  auto params = VKPCAPI::QueryParams{{"page", std::to_string(requestedPage)}, {"pageSize", "24"}, {"o", "-priority"}};
  const auto &account = AccountInfo::instance().get();
  if (account && account->contains("plan") && (*account)["plan"].is_object() &&
      (*account)["plan"].contains("plan_family") && (*account)["plan"]["plan_family"].is_string())
    params["plan_family_slug"] = (*account)["plan"]["plan_family"].get<std::string>();
  const auto life = alive;
  try {
    vkpcnx::utils::runDetached([this, life, cb, params, requestedPage] {
      vkpcnx::GamesDataSource::GamesList gamesList;
      bool ok = false;
      try {
        auto games = VKPCAPI::indexGames(params);
        if (games.is_object() && games.contains("results") && games["results"].is_array()) {
          ok = true;
          for (auto &game : games["results"]) gamesList.push_back(game);
        }
      } catch (const std::exception &) {}
      brls::sync([this, life, cb, requestedPage, ok, gamesList = std::move(gamesList)]() mutable {
        if (!life->load()) return;
        if (!ok) {
          showFailure("Не удалось загрузить каталог. X — повторить, Y — сохранить отчёт.");
          return;
        }
        page = requestedPage;
        hasMore = !gamesList.empty();
        retryPage = {};
        loading = false;
        failed = false;
        loader->setVisibility(brls::Visibility::GONE);
        content->setVisibility(brls::Visibility::VISIBLE);
        cb(std::move(gamesList));
      });
    });
  } catch (const std::exception &) {
    showFailure("Не удалось запустить загрузку каталога. Попробуйте снова.");
  }
}
