// Modified for Cloud Lite NX: startup reliability and custom identification.
#include "activity/login_activity.hpp"
#include "core/utils/navigation.hpp"
#include "core/auth/reply.hpp"
#include "core/http.hpp"
#include "core/utils/config.hpp"
#include "core/utils/device.hpp"
#include "view/qrcode.hpp"
#include <chrono>
#include <thread>

void LoginActivity::onContentReady() {
  if (Settings::instance().has("account")) {
    brls::Application::pushActivity(new MainActivity(), brls::TransitionAnimation::NONE);
    return;
  }
  appletFrame->registerAction("Отчёт об ошибке", brls::BUTTON_Y, [](brls::View *) {
    vkpcnx::openDebugReportDialog(); return true;
  });
  appletFrame->registerAction("Повторить вход", brls::BUTTON_X, [this](brls::View *) {
    if (!busy) startLogin();
    return true;
  });
  registerExitAction();
  startLogin();
}

void LoginActivity::showFailure(const std::string &message) {
  busy = false;
  getView("login/spinner")->setVisibility(brls::Visibility::GONE);
  getView("login/content")->setVisibility(brls::Visibility::GONE);
  static_cast<brls::Label *>(getView("login/errorText"))->setText(message);
  getView("login/error")->setVisibility(brls::Visibility::VISIBLE);
}

void LoginActivity::startLogin() {
  if (busy) return;
  if (attempt) attempt->store(false);
  attempt = std::make_shared<std::atomic_bool>(true);
  auto active = attempt;
  busy = true;
  getView("login/error")->setVisibility(brls::Visibility::GONE);
  getView("login/content")->setVisibility(brls::Visibility::GONE);
  getView("login/spinner")->setVisibility(brls::Visibility::VISIBLE);
  auto fail = [this, active](const std::string &message) {
    // Never log response bodies, pairing tokens or OAuth tokens.
    brls::Logger::warning("login: {}", message);
    brls::sync([this, active, message] {
      if (active->load()) showFailure(message);
    });
  };
  try {
    vkpcnx::utils::runDetached([this, active, fail] {
      using namespace vkpcnx::auth;
      auto request = [](Stage stage, const std::string &url, const Json &body) {
        auto r = Http::postJson(url, body);
        return parse(stage, r.status, r.transportCode, r.body);
      };
      try {
        auto init = request(Stage::Init, vkpcnx::utils::AUTH_API_BASE + "/tvauth/forward/init",
                            {{"target", vkpcnx::utils::getDeviceUUID()}});
        if (!active->load()) return;
        if (init.state != State::Ready) { fail(init.message); return; }
        const auto code = init.data.at("code").get<std::string>();
        const auto token = init.data.at("token").get<std::string>();
        brls::sync([this, active, code] {
          if (!active->load()) return;
          static_cast<vkpcnx::QrCode *>(getView("login/qrcode"))->setText(
            vkpcnx::utils::PAIRING_QR_LINK_PREFIX + code);
          static_cast<brls::Label *>(getView("login/pairCode"))->setText(code);
          getView("login/spinner")->setVisibility(brls::Visibility::GONE);
          getView("login/content")->setVisibility(brls::Visibility::VISIBLE);
        });
        const auto deadline = std::chrono::steady_clock::now() +
          std::chrono::seconds(vkpcnx::utils::AUTH_PULL_TOKEN_LIFETIME);
        while (active->load() && std::chrono::steady_clock::now() < deadline) {
          auto poll = request(Stage::Poll, vkpcnx::utils::AUTH_API_BASE + "/tvauth/forward/verify",
                              {{"token", token}});
          if (!active->load()) return;
          if (poll.state == State::Failed) { fail(poll.message); return; }
          if (poll.state == State::Ready) {
            auto exchange = request(Stage::Exchange, vkpcnx::utils::OAUTH_TOKEN_ENDPOINT,
              {{"client_id", vkpcnx::utils::OAUTH_CLIENT_ID}, {"code", poll.data.at("oauth2_code")}});
            if (!active->load()) return;
            if (exchange.state != State::Ready) { fail(exchange.message); return; }
            brls::sync([this, active, account = std::move(exchange.data)] {
              if (!active->load()) return;
              active->store(false);
              busy = false;
              Settings::instance().set("account", account);
              brls::Application::pushActivity(new MainActivity(), brls::TransitionAnimation::NONE);
              vkpcnx::utils::showOnboarding();
            });
            return;
          }
          for (int i = 0; i < 20 && active->load(); ++i)
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        if (active->load()) fail("Срок действия кода истёк. Нажмите X, чтобы получить новый.");
      } catch (const std::exception &) {
        if (active->load()) fail("Не удалось завершить вход. Нажмите X для повтора или Y для отчёта.");
      }
    });
  } catch (const std::exception &) {
    showFailure("Не удалось запустить подключение. Закройте приложение и попробуйте снова.");
  }
}
