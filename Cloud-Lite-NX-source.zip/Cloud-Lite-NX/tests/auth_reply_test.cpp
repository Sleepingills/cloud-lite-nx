#include "core/auth/reply.hpp"
#include <cassert>
#include <iostream>
using namespace vkpcnx::auth;
int main() {
  int count = 0;
  auto check = [&](Stage stage, long http, int transport, const std::string &body, State state) {
    auto r = parse(stage, http, transport, body);
    assert(r.state == state);
    if (state == State::Failed) assert(!r.message.empty());
    assert(r.message.find("SECRET_TOKEN") == std::string::npos);
    ++count;
  };
  for (auto stage : {Stage::Init, Stage::Poll, Stage::Exchange}) {
    for (int code : {6, 7, 28, 35, 60}) check(stage, 0, code, "", State::Failed);
    for (long status : {401, 403, 429, 500, 503})
      check(stage, status, 0, R"({"token":"SECRET_TOKEN"})", State::Failed);
    for (const char *body : {"<html>gateway</html>", "null", "[]", "{", "42"})
      check(stage, 200, 0, body, State::Failed);
  }
  check(Stage::Init,200,0,R"({"code":"1234","token":"SECRET_TOKEN"})",State::Ready);
  check(Stage::Init,200,0,R"({"code":"1234"})",State::Failed);
  check(Stage::Init,200,0,R"({"code":42,"token":"SECRET_TOKEN"})",State::Failed);
  check(Stage::Init,200,0,R"({"code":"","token":"SECRET_TOKEN"})",State::Failed);
  check(Stage::Poll,200,0,"{}",State::Pending);
  check(Stage::Poll,200,0,R"({"oauth2_code":null})",State::Pending);
  check(Stage::Poll,200,0,R"({"oauth2_code":""})",State::Pending);
  check(Stage::Poll,200,0,R"({"oauth2_code":42})",State::Failed);
  check(Stage::Poll,200,0,R"({"error":"expired"})",State::Failed);
  check(Stage::Poll,200,0,R"({"oauth2_code":"SECRET_TOKEN"})",State::Ready);
  check(Stage::Exchange,200,0,R"({"access_token":"SECRET_TOKEN"})",State::Ready);
  check(Stage::Exchange,200,0,R"({"access_token":null})",State::Failed);
  check(Stage::Exchange,200,0,R"({"access_token":""})",State::Failed);
  check(Stage::Exchange,200,0,"{}",State::Failed);
  std::cout << count << " auth response scenarios passed\n";
}
