$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Install and start Docker Desktop, then run this script again.'
}
docker info | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop is not running.' }
docker run --rm -v "${PSScriptRoot}:/work" -w /work devkitpro/devkita64:latest bash scripts/build-cloud-lite-container.sh
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Save the output to diagnose the error.' }
Write-Host 'Built: release/cloud-lite-nx.nro'
